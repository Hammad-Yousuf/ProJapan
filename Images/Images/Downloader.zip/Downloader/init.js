
var div = document.createElement("div")
div.id = "WRWHOISInstalled";
div.innerHTML = " ";
//div.style.display = "none";
//document.body.appendChild(div);